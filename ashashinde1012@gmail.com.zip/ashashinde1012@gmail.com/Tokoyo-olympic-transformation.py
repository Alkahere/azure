# Databricks notebook source

from pyspark.sql.functions import col
from pyspark.sql.types import IntegerType, DoubleType, BooleanType, DateType

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
"fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
"fs.azure.account.oauth2.client.id": "0a9c9a7d-4808-45f7-aab4-8195486e8869",
"fs.azure.account.oauth2.client.secret": "aKG8Q~xwjvCrgQubnjRuYlX1.SekLfRlzcqCAbyI",
"fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/22daa60b-0624-4ed6-a97f-03e1257ac190/oauth2/token"}


dbutils.fs.mount(
source = "abfss://olympic-data@tokoyoolympicdataset.dfs.core.windows.net", # contrainer@storageacc
mount_point = "/mnt/tokyoolymic",
extra_configs = configs)

# COMMAND ----------

# MAGIC %fs
# MAGIC ls

# COMMAND ----------

# MAGIC %fs
# MAGIC ls "mnt/tokyoolymic"
# MAGIC

# COMMAND ----------

spark

# COMMAND ----------

athletes=spark.read.format("csv").option("header","true").option("inferSchema","true").load("/mnt/tokyoolymic/raw data/athletes.csv")
coches=spark.read.format("csv").option("header","true").option("inferSchema","true").load("/mnt/tokyoolymic/raw data/coches.csv")
EntriesGender=spark.read.format("csv").option("header","true").option("inferSchema","true").load("/mnt/tokyoolymic/raw data/EntriesGender.csv")
Medals=spark.read.format("csv").option("header","true").option("inferSchema","true").load("/mnt/tokyoolymic/raw data/Medals.csv")
Teams=spark.read.format("csv").option("header","true").option("inferSchema","true").load("/mnt/tokyoolymic/raw data/Teams.csv")


# COMMAND ----------

Medals.show()

# COMMAND ----------

athletes.printSchema()

# COMMAND ----------

athletes.show()

# COMMAND ----------

coches.show()

# COMMAND ----------

coches.printSchema()

# COMMAND ----------

EntriesGender.show()

# COMMAND ----------

EntriesGender.printSchema()

# COMMAND ----------

EntriesGender = EntriesGender.withColumn("Female",col("Female").cast(IntegerType()))\
    .withColumn("Male",col("Male").cast(IntegerType()))\
    .withColumn("Total",col("Total").cast(IntegerType()))
     

# COMMAND ----------

EntriesGender.printSchema()

# COMMAND ----------

Medals.printSchema()

# COMMAND ----------

Medals.printSchema()

# COMMAND ----------

Teams.show()

# COMMAND ----------

# Find the top countries with the highest number of gold medals
top_gold_medal_countries = Medals.orderBy("Gold", ascending=False).select("Team_Country","Gold").show()

# COMMAND ----------

# Calculate the average number of entries by gender for each discipline
average_entries_by_gender = EntriesGender.withColumn(
    'Avg_Female', EntriesGender['Female'] / EntriesGender['Total']
).withColumn(
    'Avg_Male', EntriesGender['Male'] / EntriesGender['Total']
)
average_entries_by_gender.show()
     

# COMMAND ----------

athletes.write.mode("overwrite").option("header","true").csv("/mnt/tokyoolymic/transformed data/athletes")

# COMMAND ----------

coches.write.mode("overwrite").option("header","true").csv("/mnt/tokyoolymic/transformed-data/coches")
EntriesGender.write.mode("overwrite").option("header","true").csv("/mnt/tokyoolymic/transformed-data/EntriesGender")
Medals.write.mode("overwrite").option("header","true").csv("/mnt/tokyoolymic/transformed-data/Medals")
Teams.write.mode("overwrite").option("header","true").csv("/mnt/tokyoolymic/transformed-data/Teams")
     

# COMMAND ----------

athletes.write.mode("overwrite").option("header","true").csv("/mnt/tokyoolymic/transformed-data/athletes")

# COMMAND ----------

